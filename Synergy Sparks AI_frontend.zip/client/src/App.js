import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./components/HomePage"
import LoginPage from "./pages/auth/LoginPage";
import SignupPage from "./pages/auth/SignupPage";
import ApplicantPage from "./pages/applications/ApplicantPage"
import AdminPage from "./admin/AdminPage";
import BiodataForm from "./pages/form/BiodataFrom";
import Acknowledgment from "./pages/form/Status";
import EducationForm from "./pages/form/EducationForm";
import AdminLoginPage from "./pages/auth/AdminLoginPage";
import Layout from "./Layout";
import JobPostForm from "./admin/jobs/JobPostForm";
import PageNotFound from "./components/PageNotFound";
import DocumentUpload from "./pages/form/DocumentUpload";
import "./styles/App.css";

function App() {
  const isLoggedIn = !!localStorage.getItem("token"); // Example: Replace with actual auth logic

  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<HomePage />} />
        <Route path="/user/login" element={<LoginPage />} />65
        <Route path="/user/signup" element={<SignupPage />} />
        <Route path="/admin/login" element={<AdminLoginPage />} />

        {/* Protected Routes */}
        <Route element={<Layout isLoggedIn={isLoggedIn} />}>
          <Route path="/applicant" element={<ApplicantPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/application/:applicationId/biodata" element={<BiodataForm />} />
          <Route path="/application/:applicationId/education" element={<EducationForm />} />
          <Route path="/application/:applicationId/status" element={<Acknowledgment />} />
          {/* <Route path="/application/:applicationId/documents" element={<DocumentUpload />} /> */}
          <Route path="/application/:applicationId/upload" element={<DocumentUpload />} />
          <Route path="/admin/job/create" element={<JobPostForm/>} />
        </Route>
        <Route path="*" element={<PageNotFound/>} />
      </Routes>
    </Router>
  );
}

export default App;
