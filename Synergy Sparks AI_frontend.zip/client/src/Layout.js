import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import Navbar from "./components/Navbar";

const Layout = ({ isLoggedIn }) => {
  if (!isLoggedIn) {
    // Redirect to the login page if the user is not logged in
    return <Navigate to="/" replace />;
  }

  return (
    <>
      <Navbar />
      <main>
        <Outlet />
      </main>
    </>
  );
};

export default Layout;