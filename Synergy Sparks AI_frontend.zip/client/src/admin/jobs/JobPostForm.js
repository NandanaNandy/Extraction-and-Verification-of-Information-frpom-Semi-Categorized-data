import React, { useState } from "react";
import axiosInstance from "../../axiosInstance";

const JobPostForm = () => {
  // State variable to store the job title
  const [jobTitle, setJobTitle] = useState("");
  const [error, setError] = useState(null);

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const jobData = {
      title: jobTitle,
    };

    try {
      const response = await axiosInstance.post("/api/job/create", jobData);
      if (response.status === 200) {
        alert("Job posted successfully");
        setJobTitle("");
      }
    } catch (error) {
      setError("Error posting job. Please try again later.");
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white shadow-lg rounded-md">
      <h2 className="text-2xl font-semibold mb-4 text-center">Post a Job</h2>
      {error && <p className="text-red-500 text-center mb-4">{error}</p>}
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-gray-700 font-medium mb-2">Job Title:</label>
          <input
            type="text"
            value={jobTitle}
            onChange={(e) => setJobTitle(e.target.value)}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex justify-center">
          <button
            type="submit"
            className="px-6 py-2 bg-blue-500 text-white font-medium rounded-md hover:bg-blue-600 transition"
          >
            Post Job
          </button>
        </div>
      </form>
    </div>
  );
};

export default JobPostForm;
