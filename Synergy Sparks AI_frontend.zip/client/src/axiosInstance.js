import axios from 'axios';

const BASE_URL = "http://localhost:3001";
// const BASE_URL = "https://7c1c-103-212-145-239.ngrok-free.app"

const axiosInstance = axios.create({
  withCredentials: true,
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

axiosInstance.interceptors.request.use(async (config) => {
  try {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  } catch (error) {
    console.error('Failed to fetch JWT token:', error);
  }
  return config;
});

axiosInstance.interceptors.response.use(
  response => {
    return response;
  },
  error => {
    if (error.response) {
      const status = error.response.status;
      switch (status) {
        case 401:
          localStorage.clear();
          alert('Invalid login session. Please login again.');
          window.location.href = '/';
          break;
        case 403:
          alert('You do not have permission to perform this action.');
          break;
        case 404:
          if (window.location.href.includes('login')){
            alert('Invalid login details. Please try again.');
            break;
          }
          alert('The requested resource was not found.');
          break;
      }
    }

    return Promise.reject(error);
  }
);

export default axiosInstance;