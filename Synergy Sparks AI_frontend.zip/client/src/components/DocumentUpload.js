import React, { useState } from "react";

function DocumentUpload() {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
    setMessage(""); // Reset message on file selection
  };

  const handleUpload = () => {
    if (file) {
      setMessage(`File "${file.name}" is being uploaded...`);
      // Simulate upload with a timeout
      setTimeout(() => {
        setMessage(`File "${file.name}" uploaded successfully.`);
      }, 2000);
    } else {
      setMessage("Please select a file to upload.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <div className="bg-white shadow-lg rounded-lg p-6 w-full max-w-md">
        <h2 className="text-2xl font-semibold text-gray-800 text-center mb-4">
          Upload Your Document
        </h2>
        <div className="flex flex-col items-center gap-4">
          <input
            type="file"
            onChange={handleFileChange}
            className="block w-full text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-blue-500 file:text-white file:cursor-pointer file:hover:bg-blue-600"
          />
          <button
            onClick={handleUpload}
            className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md shadow transition duration-300"
          >
            Upload
          </button>
        </div>
        {message && (
          <p
            className={`mt-4 text-center text-lg ${
              message.includes("successfully")
                ? "text-green-600"
                : "text-red-600"
            }`}
          >
            {message}
          </p>
        )}
      </div>
    </div>
  );
}

export default DocumentUpload;
