import React from "react";

function Footer() {
  return (
    <footer className="w-full bg-gray-800 text-gray-200 py-4 text-center">
      <p className="text-sm font-medium">
        &copy; 2024 <span className="text-blue-400">RAC Recruitment System</span> | All Rights Reserved
      </p>
    </footer>
  );
}

export default Footer;