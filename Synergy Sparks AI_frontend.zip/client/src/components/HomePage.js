import React from "react";
import { useNavigate } from "react-router-dom";

function HomePage() {
  const navigate = useNavigate();

  const handleApplicantLogin = () => {
    navigate("/user/login");
  };

  const handleAdminLogin = () => {
    navigate("/admin/login");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <header className="bg-gray-800 text-white py-6 px-4 shadow-md">
        <div className="flex flex-col items-center">
          <img
            src="https://rac.gov.in/images/rac_logo_2019.png"
            alt="DRDO Logo"
            className="w-24 h-24"
          />
          <h1 className="text-2xl font-bold mt-4 text-center">
            Recruitment & Assessment Centre (RAC) - DRDO
          </h1>
        </div>
      </header>
      <main className="flex-grow flex flex-col items-center justify-center px-4 py-8">
        <h2 className="text-2xl font-semibold text-gray-800 mb-6">
          Welcome to the RAC Applicant Portal
        </h2>
        <p className="text-lg text-gray-600 text-center max-w-2xl mb-8">
          The Recruitment & Assessment Centre (RAC) facilitates the hiring and
          evaluation of candidates for the Defence Research and Development Organisation
          (DRDO). Use this portal to manage your applications and track your progress.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
          <div className="bg-white shadow-lg rounded-lg p-6 text-center">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">
              Applicant Portal
            </h3>
            <p className="text-gray-600 mb-6">
              Upload documents, track application status, and communicate with
              administrators regarding your application.
            </p>
            <button
              className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md shadow transition duration-300"
              onClick={handleApplicantLogin}
            >
              Login as Applicant
            </button>
          </div>
          <div className="bg-white shadow-lg rounded-lg p-6 text-center">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">
              Admin Portal
            </h3>
            <p className="text-gray-600 mb-6">
              Review and verify applicant submissions, manage reports, and
              oversee the application process.
            </p>
            <button
              className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-md shadow transition duration-300"
              onClick={handleAdminLogin}
            >
              Login as Admin
            </button>
          </div>
        </div>
      </main>
      <footer className="bg-gray-800 text-gray-200 py-4 text-center">
        <p>© 2024 Defence Research and Development Organisation. All rights reserved.</p>
        <p>
          For support, contact{" "}
          <a
            href="mailto:support@drdo.gov.in"
            className="text-blue-400 hover:text-blue-500 transition duration-300"
          >
            support@drdo.gov.in
          </a>
        </p>
      </footer>
    </div>
  );
}

export default HomePage;
