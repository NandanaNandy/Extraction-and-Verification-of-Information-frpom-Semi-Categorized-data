import React from "react";
import { Link, useNavigate } from "react-router-dom";

function Navbar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <nav className="bg-gray-800 text-gray-200 px-6 py-4 shadow-md flex justify-between items-center">
      <div className="flex items-center space-x-6">
        <Link to="/" className="text-lg font-semibold hover:text-blue-400 transition duration-300">
          Home
        </Link>
        <Link to="/profile" className="text-lg font-semibold hover:text-blue-400 transition duration-300">
          Profile
        </Link>
      </div>
      <div className="flex items-center space-x-4">
        <button
          onClick={handleLogout}
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md shadow transition duration-300"
        >
          Logout
        </button>
      </div>
    </nav>
  );
}

export default Navbar;
