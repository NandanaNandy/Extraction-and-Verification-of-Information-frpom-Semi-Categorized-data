import React, { useState } from "react";

function StatusTracker() {
  const [applicants, setApplicants] = useState([
    { name: "John Doe", status: "Pending" },
    { name: "Jane Smith", status: "Verified" },
    { name: "Mike Johnson", status: "Rejected" },
  ]);

  return (
    <div className="flex flex-col items-center w-full py-8 bg-gray-100 min-h-screen">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Applicant Status</h2>
      <div className="w-full max-w-4xl bg-white shadow-lg rounded-lg overflow-hidden">
        <table className="table-auto w-full text-left border-collapse">
          <thead className="bg-gray-800 text-gray-200">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {applicants.map((applicant, index) => (
              <tr
                key={index}
                className={`${
                  index % 2 === 0 ? "bg-gray-100" : "bg-gray-50"
                } hover:bg-blue-50`}
              >
                <td className="px-4 py-3 text-gray-800">{applicant.name}</td>
                <td
                  className={`px-4 py-3 font-semibold ${
                    applicant.status === "Verified"
                      ? "text-green-600"
                      : applicant.status === "Rejected"
                      ? "text-red-600"
                      : "text-yellow-600"
                  }`}
                >
                  {applicant.status}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default StatusTracker;
