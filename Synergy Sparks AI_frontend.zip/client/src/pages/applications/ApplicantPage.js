import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axiosInstance from "../../axiosInstance";

function ApplicantPage() {
  const [acknowledgmentNumber, setAcknowledgmentNumber] = useState("");
  const [status, setStatus] = useState(null);
  const [error, setError] = useState("");
  const [jobs, setJobs] = useState([]);  // State for storing job posts
  const [loading, setLoading] = useState(true); // State for loading status
  const [searchTerm, setSearchTerm] = useState(""); // State for search term

  // Fetch job data from backend
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await axiosInstance.get("/api/job");
        if (response.status == 200) {
          setJobs(response.data.jobs);
        } else {
          console.error("Failed to fetch jobs");
        }
      } catch (error) {
        console.error("Error fetching jobs:", error);
      } finally {
        setLoading(false);  // Stop loading after fetching
      }
    };

    fetchJobs();
  }, []); // Empty dependency array ensures the effect runs only once when the component mounts

  const handleStatusCheck = () => {
    if (!acknowledgmentNumber) {
      setError("Please enter the acknowledgment number.");
      return;
    }

    setError(""); // Reset error state

    const statuses = {
      "12345": "In Progress",
      "67890": "Under Review",
      "11223": "Verified",
      "44556": "Flagged",
    };

    if (statuses[acknowledgmentNumber]) {
      setStatus(statuses[acknowledgmentNumber]);
    } else {
      setStatus("No application found for this acknowledgment number.");
    }
  };

  const filteredJobs = jobs.filter(job => 
    new RegExp(searchTerm, "i").test(job.title)
  );

  return (
    <div className="min-h-screen bg-gray-100 p-6 flex items-center justify-center">
      <div className="max-w-6xl w-full bg-white shadow-lg rounded-lg flex">
        {/* Job Search Section */}
        <div className="w-7/12 p-8">
          <h1 className="text-3xl font-bold text-center text-blue-600 mb-6">
            RAC DRDO Applicant Dashboard
          </h1>

          {/* Job Search */}
          <div className="mb-8">
            <input
              type="text"
              placeholder="Search Jobs"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full border border-gray-300 rounded-md p-3 mb-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Job Selection */}
          <div className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">
              Available Jobs
            </h2>
            <div className="space-y-4">
              {loading ? (
                <p>Loading jobs...</p>
              ) : (
                filteredJobs.map((job, index) => (
                  <div
                    key={index}
                    className="border border-gray-300 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
                  >
                    <h3 className="text-xl font-medium text-gray-900 mb-2">
                      {job.title}
                    </h3>
                    <p className="text-gray-700 mb-4">Posted on: {new Date(job.createdAt).toLocaleDateString()}</p>
                    <Link to={`/application/${job._id}/biodata`}>
                      <button className="bg-blue-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-blue-700 transition duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        Apply Now
                      </button>
                    </Link>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Application Tracking Section */}
        <div className="w-5/12 p-8 border-l border-gray-300">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">
            Track Your Application Status
          </h2>
          <p className="text-gray-600 mb-4">
            Enter your acknowledgment number to check the application status:
          </p>
          <input
            type="text"
            placeholder="Enter Acknowledgment Number"
            value={acknowledgmentNumber}
            onChange={(e) => setAcknowledgmentNumber(e.target.value)}
            className="w-full border border-gray-300 rounded-md p-3 mb-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={handleStatusCheck}
            className="w-full bg-green-600 text-white font-semibold py-2 rounded-md hover:bg-green-700 transition duration-300 focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            Check Status
          </button>
          {error && <p className="text-red-600 mt-4">{error}</p>}
          {status && (
            <div className="mt-4 bg-gray-100 p-4 rounded-md">
              <h4 className="text-lg font-medium">Status: {status}</h4>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ApplicantPage;