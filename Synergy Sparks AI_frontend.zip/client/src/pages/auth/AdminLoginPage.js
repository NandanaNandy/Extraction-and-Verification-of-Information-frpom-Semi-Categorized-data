import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../axiosInstance";
// import "./AdminLoginPage.css";

function AdminLoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("adminToken");
    if (token) {
      navigate("/admin-dashboard");
    }
  }, [navigate]);

  const handleLogin = async () => {
    if (!username || !password) {
      setError("Please enter both username and password.");
      return;
    }

    try {
      const response = await axiosInstance.post("/admin/login", {
        username,
        password,
      });

      if (response.status === 200) {
        // Store admin token in localStorage
        localStorage.setItem("adminToken", response.data.token);
        navigate("/admin-dashboard");
      } else {
        setError(response.data.message || "Invalid username or password.");
      }
    } catch (error) {
      // Handle errors
      if (error.response) {
        setError(
          error.response.data.message || "Failed to authenticate. Please try again."
        );
      } else if (error.request) {
        setError("No response from server. Please check your connection.");
      } else {
        setError("An error occurred. Please try again.");
      }
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 p-6">
      <div className="max-w-sm w-full bg-white shadow-lg rounded-lg p-8">
        <h1 className="text-3xl font-semibold text-center text-blue-600 mb-4">
          Admin Portal
        </h1>
        <p className="text-center text-gray-600 mb-6">
          Secure Login for Administrators
        </p>

        <input
          className="w-full border border-gray-300 rounded-md p-3 mb-4 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          className="w-full border border-gray-300 rounded-md p-3 mb-4 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          className="w-full bg-blue-600 text-white font-semibold py-2 rounded-md hover:bg-blue-700 transition duration-300"
          onClick={handleLogin}
        >
          Login
        </button>

        {error && (
          <p className="mt-4 text-center text-red-600 font-semibold">
            {error}
          </p>
        )}
      </div>
    </div>
  );
}

export default AdminLoginPage;
