import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../axiosInstance"; // Use axiosInstance
// import "./SignupPage.css";

function SignupPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/applicant");
    }
  }, [navigate]);

  const validatePassword = (password) => {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/;
    return regex.test(password);
  };

  const handleSignup = async () => {
    if (!username || !password || !confirmPassword) {
      setError("Please fill in all fields.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (!validatePassword(password)) {
      setError(
        "Password must be at least 8 characters long, contain uppercase and lowercase letters, a number, and a special character."
      );
      return;
    }

    try {
      const response = await axiosInstance.post("/api/register", {
        username,
        password,
      });

      if (response.status === 200) {
        setMessage("Signup successful! Redirecting to login...");
        setError("");
        setTimeout(() => {
          navigate("/user/login");
        }, 2000);
      } else {
        setError(response.data.message || "Signup failed. Please try again.");
      }
    } catch (error) {
      if (error.response) {
        setError(
          error.response.data.message ||
            "Failed to create an account. Please try again."
        );
      } else if (error.request) {
        setError("No response from server. Please check your connection.");
      } else {
        setError("An error occurred. Please try again.");
      }
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 p-6">
      <div className="max-w-sm w-full bg-white shadow-lg rounded-lg p-8">
        <h1 className="text-3xl font-semibold text-center text-blue-600 mb-4">
          Applicant Signup
        </h1>
        <p className="text-center text-gray-600 mb-6">
          Create your account to apply for RAC DRDO jobs
        </p>

        <input
          className="w-full border border-gray-300 rounded-md p-3 mb-4 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          type="text"
          placeholder="Enter Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          className="w-full border border-gray-300 rounded-md p-3 mb-4 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <input
          className="w-full border border-gray-300 rounded-md p-3 mb-4 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          type="password"
          placeholder="Confirm Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
        />

        <button
          className="w-full bg-blue-600 text-white font-semibold py-2 rounded-md hover:bg-blue-700 transition duration-300"
          onClick={handleSignup}
        >
          Sign Up
        </button>

        {message && (
          <p className="mt-4 text-center text-green-600 font-semibold">{message}</p>
        )}
        {error && (
          <p className="mt-4 text-center text-red-600 font-semibold">{error}</p>
        )}

        <p className="mt-6 text-center text-gray-600">
          Already have an account?{" "}
          <a href="/user/login" className="text-blue-600 hover:text-blue-700">
            Login here
          </a>
          .
        </p>

        <div className="mt-6 text-start text-gray-600">
          <p className="text-sm">
            <strong>Password Guidelines:</strong>
            <ul className="list-disc list-inside text-xs text-gray-500">
              <li>At least 8 characters long</li>
              <li>Contains both uppercase and lowercase letters</li>
              <li>Includes a number and a special character (!@#$%^&*)</li>
            </ul>
          </p>
        </div>
      </div>
    </div>
  );
}

export default SignupPage;
