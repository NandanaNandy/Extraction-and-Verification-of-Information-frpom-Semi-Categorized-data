import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axiosInstance from "../../axiosInstance";

function BiodataForm() {
  const { applicationId } = useParams();
  const [error, setError] = useState("");
  const [previewImage, setPreviewImage] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    dob: "",
    gender: "",
    maritalStatus: "",
    contact: "",
    email: "",
    address: "",
    profilePicture: "",
  });
  const navigate = useNavigate();

  function convertImageToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  }

  useEffect(() => {
    if (applicationId) {
      const fetchBiodata = async () => {
        try {
          const response = await axiosInstance.get(`/api/application/${applicationId}/biodata`);
          const data = response.data;

          console.log("Fetched biodata:", data);
          // Update form data and preview image
          setFormData(data);
          if (data.profilePicture) {
            setPreviewImage(data.profilePicture); // Assume it's already Base64
          }
        } catch (err) {
          console.error("Error fetching biodata:", err);
        }
      };
      fetchBiodata();
    }
  }, [applicationId]);

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (file) {
      const base64 = await convertImageToBase64(file);
      setFormData((prevData) => ({ ...prevData, profilePicture: base64 }));
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const validateForm = () => {
    const { name, contact, email, dob } = formData;
    if (!name.match(/^[a-zA-Z\s]+$/)) {
      setError("Name must contain only letters and spaces.");
      return false;
    }
    if (!contact.match(/^\d{10}$/)) {
      setError("Contact must be a 10-digit number.");
      return false;
    }
    if (!email.match(/^\S+@\S+\.\S+$/)) {
      setError("Invalid email format.");
      return false;
    }
    if (!dob) {
      setError("Date of Birth is required.");
      return false;
    }
    setError("");
    return true;
  };

  const handleNext = async (event) => {
    event.preventDefault();
    if (!validateForm()) return;

    try {
      const response = await axiosInstance.post(
        `/api/application/${applicationId}/biodata`,
        {
          name: formData.name,
          date_of_birth : formData.dob,
          gender: formData.gender,
          maritalStatus: formData.maritalStatus,
          contact: formData.contact,
          email: formData.email,
          address: formData.address,
          profilePicture: formData.profilePicture
        }
      );

      navigate(`/application/${applicationId}/education`);
    } catch (err) {
      setError("Failed to save biodata. Please try again.");
      console.error(err);
    }
  };

  const handleDownload = () => {
    const link = document.createElement("a");
    link.href = previewImage;
    link.download = "profile_picture.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl w-full bg-white rounded-lg shadow-lg p-8">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">Biodata Form</h2>
        <form className="space-y-6" onSubmit={handleNext}>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your full name"
              className="input-field"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
            <input
              type="date"
              name="dob"
              value={formData.dob}
              onChange={handleChange}
              className="input-field"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
            <select
              name="gender"
              value={formData.gender}
              onChange={handleChange}
              className="input-field"
            >
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Marital Status</label>
            <select
              name="maritalStatus"
              value={formData.maritalStatus}
              onChange={handleChange}
              className="input-field"
            >
              <option value="">Select Status</option>
              <option value="Single">Single</option>
              <option value="Married">Married</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Contact Number</label>
            <input
              type="text"
              name="contact"
              value={formData.contact}
              onChange={handleChange}
              placeholder="Enter your contact number"
              className="input-field"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email address"
              className="input-field"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
            <textarea
              name="address"
              value={formData.address}
              onChange={handleChange}
              placeholder="Enter your address"
              className="input-field"
            ></textarea>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Profile Picture</label>
            <input
              type="file"
              name="profilePicture"
              accept="image/*,application/pdf"
              onChange={handleFileChange}
              className="input-field"
            />
          </div>

          {previewImage && (
            <div className="mt-4 text-center">
              <img
                src={previewImage}
                alt="Preview"
                className="rounded-lg shadow-lg w-32 h-32 object-cover mx-auto"
              />
              <button
                type="button"
                onClick={handleDownload}
                className="btn-secondary mt-2 bg-blue-500 text-white py-1 px-3 rounded-lg hover:bg-blue-600 transition duration-300"
              >
                Download Image
              </button>
            </div>
          )}

          {error && <p className="text-center text-red-600 font-medium mt-4">{error}</p>}

          <div className="text-center mt-6">
            <button
              type="submit"
              className="btn-primary w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition duration-300"
            >
              Save as Draft
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default BiodataForm;
