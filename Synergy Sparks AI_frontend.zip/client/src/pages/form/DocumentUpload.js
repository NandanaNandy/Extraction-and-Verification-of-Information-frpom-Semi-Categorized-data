import React, { useState, useEffect } from 'react';
import axiosInstance from '../../axiosInstance';
import { useParams } from 'react-router-dom';
import FolderUploader from './FolderUploader';

const DocumentUpload = () => {
    const { applicationId } = useParams();
    const [documents, setDocuments] = useState({});
    const [loading, setLoading] = useState({});
    const [errors, setErrors] = useState({});
    const [serverMessages, setServerMessages] = useState({});
    const [userDetails, setUserDetails] = useState({});

    useEffect(() => {
        const fetchApplicationData = async () => {
            try {
                const response = await axiosInstance.get(`/api/application/${applicationId}/details`);
                const fetchedUserDetails = response.data || {};
                console.log(fetchedUserDetails);
                setUserDetails(fetchedUserDetails);
            } catch (err) {
                console.error('Error fetching application data', err);
            }
        };

        fetchApplicationData();
    }, [applicationId]);

    const documentSchemas = {
        'birth_cert': { name: 'String', date_of_birth: 'Date Format (DD-MM-YYYY)' },
        'degree_cert': {
            name: 'String', university: 'String', date_of_birth: 'Date Format (DD-MM-YYYY)', degree: 'String',
            cgpa: 'Float', percentage: 'Float', class: 'String', qualification_degree: 'String'
        },
        'proof_of_class': { name: 'String', class: 'String' },
        'provisional_cert': { name: 'String', degree: 'String', university: 'String', passing_year: 'Number', qualification_degree: 'String' },
        'experience_cert': { from_date: 'String (YYYY-MM-DD)', to_date: 'String (YYYY-MM-DD)' },
        'gate_score_card': { name: 'String', year: 'Number', marks: 'Number', rank: 'Number' },
        'proof_of_category': { name: 'String', category: 'String' },
        'proof_of_address': { name: 'String', address: 'String' },
        'phd_cert': {
            name: 'String', university: 'String', Date_of_reg: 'String (YYYY-MM-DD)', title_of_project: 'String',
            no_of_papers_published: 'Integer', no_of_conference_attended: 'Integer'
        },
        'aadhaar': {},
        "marksheet": {}
    };

    const handleFileChange = (documentType, file) => {
        setDocuments(prev => ({ ...prev, [documentType]: file }));
        setErrors(prev => ({ ...prev, [documentType]: null }));

        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
        if (file && !allowedTypes.includes(file.type)) {
            setErrors(prev => ({ ...prev, [documentType]: 'Please upload a valid file (PDF or image)' }));
            setDocuments(prev => ({ ...prev, [documentType]: null }));
        }
    };

    const handleSubmit = (documentType) => {
        if (!documents[documentType]) {
            setErrors(prev => ({ ...prev, [documentType]: 'Please upload a file' }));
            return;
        }

        setLoading(prev => ({ ...prev, [documentType]: true }));

        const formData = new FormData();
        formData.append('file', documents[documentType]);
        formData.append('schema', documentType);
        formData.append('userDetails', JSON.stringify(userDetails));
        setErrors([]);

        axiosInstance.post(`/api/application/${applicationId}/upload`, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
        .then(response => {
            if (response.data.error) {
                setErrors(prev => ({ ...prev, [documentType]: response.data.error }));
            } else {
                setErrors(prev => ({ ...prev, [documentType]: null }));
                setServerMessages(prev => ({ ...prev, [documentType]: response.data.message || 'Upload successful' }));
            }
        })
        .catch(err => {
            if (err.response) {
                const serverErrorMessage = err.response.data.error || 'An error occurred on the server.';
                setErrors(prev => ({ ...prev, [documentType]: serverErrorMessage }));
            } else if (err.request) {
                setErrors(prev => ({ ...prev, [documentType]: 'No response received from the server. Please try again later.' }));
            } else {
                setErrors(prev => ({ ...prev, [documentType]: err.message }));
            }
        })
        .finally(() => {
            setLoading(prev => ({ ...prev, [documentType]: false }));
        });
    };

    return (
        <div className="max-w-4xl mx-auto mt-10 p-6 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-6">Upload Documents</h2>
            <FolderUploader applicationId={applicationId}/>

            {/* {Object.keys(documentSchemas).map((docType) => (
                <div key={docType} className="mb-6 border p-4 rounded-md shadow">
                    <h3 className="text-xl font-semibold mb-4">
                        {docType.replace(/_/g, ' ').replace(/\b\w/g, (char) => char.toUpperCase())}
                    </h3>

                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2">Upload File:</label>
                        <input
                            type="file"
                            accept="application/pdf,image/jpeg,image/png"
                            onChange={(e) => handleFileChange(docType, e.target.files[0])}
                            className="input-field"
                        />
                        {errors[docType] && (
                            <div>
                                <h4 className="text-red-600 font-bold">Need your attention</h4>
                                {Array.isArray(errors[docType]) ? (
                                    errors[docType].map((error, index) => (
                                        <p key={index} className="text-red-600">{error}</p>
                                    ))
                                ) : (
                                    <p className="text-red-600">{errors[docType]}</p>
                                )}
                            </div>
                        )}
                    </div>

                    <div className="flex justify-end">
                        <button
                            type="button"
                            onClick={() => handleSubmit(docType)}
                            disabled={loading[docType]}
                            className="btn-primary px-4 py-2 bg-blue-600 text-white rounded-lg"
                        >
                            {loading[docType] ? 'Uploading...' : 'Upload'}
                        </button>
                    </div>

                    {serverMessages[docType] && (
                        <div className="mt-4">
                            {Array.isArray(serverMessages[docType]) ? (
                                serverMessages[docType].map((msg, index) => (
                                    <p key={index} className="text-green-600">{msg}</p>
                                ))
                            ) : (
                                <p className="text-green-600">{serverMessages[docType]}</p>
                            )}
                        </div>
                    )}
                </div>
            ))} */}
        </div>
    );
};

export default DocumentUpload;