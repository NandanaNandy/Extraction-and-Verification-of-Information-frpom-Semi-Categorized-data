import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axiosInstance from "../../axiosInstance";

function EducationForm() {
  const { applicationId } = useParams();
  const [ education, setEducation ] = useState([
    { degree: "", university: "", year: "", grade: "" },
  ]);
  const [gateDetails, setGateDetails] = useState({
    scoreCard: "",
    rank: "",
    score: "",
    examYear: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axiosInstance.get(`/api/application/${applicationId}/education`);
        const { degree = [{ degree: "", university: "", year: "", grade: "" }], gateDetails = { scoreCard: "", rank: "", score: "", examYear: "" } } = response.data.education;
        setEducation(degree);
        setGateDetails(gateDetails);
      } catch (err) {
        setError("Failed to fetch education details. Please try again.");
        console.error(err);
      }
    };

    if (applicationId) {
      fetchData();
    }
  }, [applicationId]);

  const handleChange = (index, e) => {
    const { name, value } = e.target;
    const updatedEducation = [...education];
    updatedEducation[index][name] = value;
    setEducation(updatedEducation);
  };

  const handleGateChange = (e) => {
    const { name, value } = e.target;
    setGateDetails({ ...gateDetails, [name]: value });
  };

  const addEducation = () => {
    setEducation([...education, { degree: "", university: "", year: "", grade: "" }]);
  };

  const deleteEducation = (index) => {
    if (education.length > 1) {
      const updatedEducation = [...education];
      updatedEducation.splice(index, 1);
      setEducation(updatedEducation);
    } else {
      setError("You must have at least one degree entered.");
    }
  };

  const validateForm = () => {
    for (const edu of education) {
      if (!edu.degree || !edu.university || !edu.year || !edu.grade) {
        setError("All fields are required for each degree entry.");
        return false;
      }
      if (!/^\d{4}$/.test(edu.year)) {
        setError("Year must be a valid 4-digit number.");
        return false;
      }
    }
    if (
      !gateDetails.scoreCard ||
      !gateDetails.rank ||
      !gateDetails.score ||
      !gateDetails.examYear
    ) {
      setError("All GATE details fields are required.");
      return false;
    }
    setError("");
    return true;
  };

  const handleNext = async (event) => {
    event.preventDefault();
    if (!validateForm()) return;

    try {
      await axiosInstance.post(`./api/application/${applicationId}/education`,  {
        degree: education,
        gateDetails,
      });
      navigate(`/application/${applicationId}/upload`);
    } catch (err) {
      setError("Failed to save education details. Please try again.");
      console.error(err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-8 bg-gray-50 border rounded-lg shadow-md">
      <h1 className="text-2xl font-bold text-center text-blue-800 mb-6">
        Educational Qualifications
      </h1>

      {/* GATE Exam Details */}
      <div className="p-6 mb-8 bg-blue-100 border border-blue-300 rounded-md">
        <h2 className="text-xl font-semibold text-blue-800 mb-4">GATE Exam Details</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              GATE Score Card<span className="text-red-500">*</span>
            </label>
            <input
              required
              type="text"
              name="scoreCard"
              placeholder="Upload or Enter details"
              value={gateDetails.scoreCard}
              onChange={handleGateChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Overall Rank in India<span className="text-red-500">*</span>
            </label>
            <input
              required
              type="text"
              name="rank"
              placeholder="e.g., 123"
              value={gateDetails.rank}
              onChange={handleGateChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              GATE Score<span className="text-red-500">*</span>
            </label>
            <input
              required
              type="text"
              name="score"
              placeholder="e.g., 850"
              value={gateDetails.score}
              onChange={handleGateChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              GATE Exam Year<span className="text-red-500">*</span>
            </label>
            <input
              required
              type="text"
              name="examYear"
              placeholder="e.g., 2023"
              value={gateDetails.examYear}
              onChange={handleGateChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Education Details */}
      <div className="space-y-6">
        {education.map((edu, index) => (
          <div key={index} className="p-6 mb-4 bg-white border rounded-md shadow-sm">
            <h3 className="text-lg font-semibold text-blue-800 mb-4">Degree {index + 1}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Degree</label>
                <input
                  required
                  type="text"
                  name="degree"
                  value={edu.degree}
                  onChange={(e) => handleChange(index, e)}
                  className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">University</label>
                <input
                  required
                  type="text"
                  name="university"
                  value={edu.university}
                  onChange={(e) => handleChange(index, e)}
                  className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Year</label>
                <input
                  required
                  type="text"
                  name="year"
                  value={edu.year}
                  onChange={(e) => handleChange(index, e)}
                  className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Grade</label>
                <input
                  required
                  type="text"
                  name="grade"
                  value={edu.grade}
                  onChange={(e) => handleChange(index, e)}
                  className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="flex justify-between mt-4">
              <button
                type="button"
                onClick={() => deleteEducation(index)}
                className="text-red-600 hover:text-red-800"
              >
                Delete Degree
              </button>
            </div>
          </div>
        ))}

        <button
          type="button"
          onClick={addEducation}
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 mt-4"
        >
          Add Another Degree
        </button>
      </div>

      {/* Error message */}
      {error && <p className="text-center text-red-600 font-medium mt-4">{error}</p>}

      {/* Submit Button */}
      <div className="text-center mt-6">
        <button
          type="submit"
          onClick={handleNext}
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition duration-300"
        >
          Save and Proceed
        </button>
      </div>
    </div>
  );
}

export default EducationForm;
