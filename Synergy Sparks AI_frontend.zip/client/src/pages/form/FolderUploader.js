import React, { useState, useEffect } from "react";
import axiosInstance from "../../axiosInstance";

const FolderUploader = ({ applicationId }) => {
  const [files, setFiles] = useState({ pdfs: [], images: [] });
  const [executionMessages, setExecutionMessages] = useState({}); // Tracks messages for each file
  const [isExecuting, setIsExecuting] = useState(false); // Tracks execution status
  const [selectedDocumentType, setSelectedDocumentType] = useState(""); // Tracks selected document type
  const [userDetails, setUserDetails] = useState({});

  useEffect(() => {
    const fetchApplicationData = async () => {
      try {
        const response = await axiosInstance.get(
          `/api/application/${applicationId}/details`
        );
        const fetchedUserDetails = response.data || {};
        console.log(fetchedUserDetails);
        setUserDetails(fetchedUserDetails);
      } catch (err) {
        console.error("Error fetching application data", err);
      }
    };

    fetchApplicationData();
  }, [applicationId]);

  const handleFolderUpload = (event) => {
    const uploadedFiles = Array.from(event.target.files);
    const classifiedFiles = uploadedFiles.reduce(
      (acc, file) => {
        const fileType = file.type;
        if (fileType.includes("pdf")) {
          acc.pdfs.push(file);
        } else if (fileType.includes("image")) {
          acc.images.push(file);
        }
        return acc;
      },
      { pdfs: [], images: [] }
    );
    setFiles(classifiedFiles);
  };

  const documentSchemas = {
    birth_cert: { name: "String", date_of_birth: "Date Format (DD-MM-YYYY)" },
    degree_cert: {
      name: "String",
      university: "String",
      date_of_birth: "Date Format (DD-MM-YYYY)",
      degree: "String",
      cgpa: "Float",
      percentage: "Float",
      class: "String",
      qualification_degree: "String",
    },
    proof_of_class: { name: "String", class: "String" },
    provisional_cert: {
      name: "String",
      degree: "String",
      university: "String",
      passing_year: "Number",
      qualification_degree: "String",
    },
    experience_cert: {
      from_date: "String (YYYY-MM-DD)",
      to_date: "String (YYYY-MM-DD)",
    },
    gate_score_card: {
      name: "String",
      year: "Number",
      marks: "Number",
      rank: "Number",
    },
    proof_of_category: { name: "String", category: "String" },
    proof_of_address: { name: "String", address: "String" },
    phd_cert: {
      name: "String",
      university: "String",
      Date_of_reg: "String (YYYY-MM-DD)",
      title_of_project: "String",
      no_of_papers_published: "Integer",
      no_of_conference_attended: "Integer",
    },
    aadhaar: {},
    marksheet: {},
  };

  const startExecution = async () => {
    setIsExecuting(true);
    const allFiles = [...files.pdfs, ...files.images];
    const newMessages = { ...executionMessages };

    for (const file of allFiles) {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("schema", selectedDocumentType);
      formData.append("userDetails", JSON.stringify(userDetails)); // Replace with actual user details

      try {
        const response = await axiosInstance.post(
          `/api/application/${applicationId}/upload`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );

        const { messages, entity } = response.data;

        // Store messages for the file
        newMessages[file.name] = messages || [
          { key: "info", value: "Execution successful" },
        ];
        setExecutionMessages(newMessages);
      } catch (error) {
        newMessages[file.name] = [
          {
            key: "error",
            value: `Error during execution: ${error.data?.error}`,
          },
        ];
      }
    }

    setExecutionMessages(newMessages);
    setIsExecuting(false);
  };

  return (
    <div className="p-6 bg-gray-100 h-screen">
      <div className="mx-auto">
        <div className="mb-4">
          <label
            htmlFor="folder-upload"
            className="block text-lg font-semibold text-gray-700 mb-2"
          >
            Upload a Folder
          </label>
          <input
            id="folder-upload"
            type="file"
            webkitdirectory="true"
            directory="true"
            multiple
            className="block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            onChange={handleFolderUpload}
          />
        </div>

        <div className="mb-4">
          <label
            htmlFor="document-type"
            className="block text-lg font-semibold text-gray-700 mb-2"
          >
            Select Document Type
          </label>
          <select
            id="document-type"
            value={selectedDocumentType}
            onChange={(e) => setSelectedDocumentType(e.target.value)}
            className="block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">Select a document type</option>
            {Object.keys(documentSchemas).map((docType) => (
              <option key={docType} value={docType}>
                {docType}
              </option>
            ))}
          </select>
        </div>

        <div className="mb-6">
          <button
            onClick={startExecution}
            disabled={isExecuting || !selectedDocumentType}
            className={`px-4 py-2 rounded-md ${
              isExecuting || !selectedDocumentType
                ? "bg-gray-300 text-gray-600 cursor-not-allowed"
                : "bg-indigo-500 text-white hover:bg-indigo-600"
            }`}
          >
            {isExecuting ? "Executing..." : "Start Execution"}
          </button>
        </div>

        <div className="mt-6">
          {files.pdfs.length > 0 && (
            <div>
              <h2 className="text-xl font-bold mb-4">PDF Files</h2>
              <div className="space-y-4">
                {files.pdfs.map((pdf, index) => (
                  <div
                    key={index}
                    className="border border-gray-300 rounded-md p-4 bg-white shadow-md flex"
                  >
                    <div className="w-2/3">
                      <p className="text-lg font-semibold text-gray-700 mb-2">
                        {pdf.name}
                      </p>
                      <embed
                        src={URL.createObjectURL(pdf)}
                        type="application/pdf"
                        className="w-full h-48"
                      />
                    </div>
                    <div className="w-1/3 pl-4">
                      <h3 className="font-bold text-gray-600 mb-2">Messages</h3>
                      <ul className="text-sm text-gray-700">
                        {(executionMessages[pdf.name] || []).map((msg, idx) => (
                          <li key={idx}>
                            &#8226; <strong>{msg.key}:</strong> {msg.value}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {files.images.length > 0 && (
            <div className="mt-8">
              <h2 className="text-xl font-bold mb-4">Image Files</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {files.images.map((image, index) => (
                  <div
                    key={index}
                    className="border border-gray-300 rounded-md p-4 bg-white shadow-md"
                  >
                    <div className="w-full">
                      <p className="text-sm font-semibold text-gray-700 mb-2 truncate">
                        {image.name}
                      </p>
                      <div className="w-full h-48 flex items-center justify-center bg-gray-100 rounded-md overflow-hidden">
                        <img
                          src={URL.createObjectURL(image)}
                          alt={image.name}
                          className="h-full object-contain"
                        />
                      </div>
                    </div>
                    <div className="mt-4">
                      <h3 className="font-bold text-gray-600 mb-2">Messages</h3>
                      <ul className="text-sm text-gray-700">
                        {(executionMessages[image.name] || []).map(
                          (msg, idx) => (
                            <li key={idx}>
                              &#8226; <strong>{msg.key}:</strong> {msg.value}
                            </li>
                          )
                        )}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FolderUploader;
