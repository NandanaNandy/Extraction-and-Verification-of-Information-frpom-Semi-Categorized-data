import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function Acknowledgement() {
  const { applicationId: acknowledgementNumber } = useParams();
  const [submissionDate, setSubmissionDate] = useState(new Date().toLocaleString());

  const copyToClipboard = () => {
    navigator.clipboard.writeText(acknowledgementNumber);
    alert("Acknowledgement number copied to clipboard!");
  };

  const printAcknowledgement = () => {
    const printWindow = window.open("", "_blank");
    const acknowledgementContent = document.getElementById("acknowledgement-content").innerHTML;

    printWindow.document.write(`
      <html>
        <head>
          <style>
            body {
              font-family: Arial, sans-serif;
            }
            .content {
              margin: 20px;
              text-align: center;
            }
            .content h1 {
              font-size: 24px;
              color: green;
            }
            .content p {
              font-size: 16px;
              color: #555;
            }
            .content .ack-number {
              font-family: monospace;
              font-size: 20px;
              color: blue;
            }
            .content button {
              background-color: green;
              color: white;
              padding: 10px 20px;
              border: none;
              border-radius: 5px;
              cursor: pointer;
            }
            .content button:hover {
              background-color: darkgreen;
            }
          </style>
        </head>
        <body>
          <div class="content">
            ${acknowledgementContent}
          </div>
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.print();
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white shadow-lg rounded-lg p-8 max-w-md w-full text-center">
        {/* Hidden navbar for print view */}
        <div className="hidden-print">
          {/* Your Navbar here (if any) */}
        </div>

        <div id="acknowledgement-content">
          <h1 className="text-2xl font-bold text-green-600 mb-4">
            Application Submitted Successfully!
          </h1>
          <p className="text-gray-700 mb-6">
            Thank you for your application. Your submission has been received.
          </p>
          <div className="bg-gray-100 rounded-lg p-4 mb-6 border border-gray-300">
            <h3 className="text-lg font-semibold text-gray-800">
              Your Acknowledgement Number:
            </h3>
            <p className="text-xl font-mono text-blue-600 mt-2">
              {acknowledgementNumber}
            </p>
            <button
              onClick={copyToClipboard}
              className="mt-4 bg-blue-500 text-white py-2 px-4 rounded"
            >
              Copy to Clipboard
            </button>
          </div>
          <p className="text-gray-600 mb-4">
            Please save this number for future reference.
          </p>
          <div className="bg-gray-100 rounded-lg p-4 mb-6 border border-gray-300">
            <h3 className="text-lg font-semibold text-gray-800">
              Submission Date:
            </h3>
            <p className="text-xl font-mono text-blue-600 mt-2">
              {submissionDate}
            </p>
          </div>
          <button
            onClick={printAcknowledgement}
            className="bg-green-500 text-white py-2 px-4 rounded"
          >
            Print Acknowledgement
          </button>
        </div>
      </div>
    </div>
  );
}

export default Acknowledgement;
